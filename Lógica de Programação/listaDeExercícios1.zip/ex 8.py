#8. Monitorameno de CPU
contador = 10
while contador <= 100:
        print(contador,"%")
        contador += 10

#23. Sistema de autentificação com tentetivas
tentativas = 0
while tentativas <3:
    usuario = input("Digite onome de usuário: ")
    senha = input("Digite sua senha: ")
    if usuario == "admin" and senha == "1234":
        print("Login realizado com sucesso!")
        break
tentativas+=1
print("Credenciais inválidas")
if tentativas == 3:
        print("Conta bloqueada")

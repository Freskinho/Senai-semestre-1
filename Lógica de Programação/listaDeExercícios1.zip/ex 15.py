#15. Controle de estoque
prod = input("Qual é o produto: ")
estoque = 67
vend = input("Quantas unidades do produto foram vendidas: ")
at = input("Quantas unidades do produto ainda restam: ")

if estoque > vend:
    print("")

#7. Contador de deploys
for i in range(1, 11):
    print("Deploy", i)

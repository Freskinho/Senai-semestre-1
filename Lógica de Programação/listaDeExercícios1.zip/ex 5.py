#5. Sistema de login simples
usuario = int(input("Digite seu nome de usuário: "))
senha = int(input("Digite sua senha: "))
if usuario == "admin" and senha == "1234":
    print("Login realizado com sucesso!")
else:
    print("Credenciais inválidas")

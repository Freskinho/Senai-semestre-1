#12. Gerador de tabuada
numero = int(input("Insira um número para ver sua tabuada: "))
print(numero*1, numero*2, numero*3, numero*4, numero*5, numero*6, numero*7, numero*8, numero*9, numero*10)

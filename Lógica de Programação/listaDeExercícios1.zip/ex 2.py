#2. Calculadora de soma de créditos
saldo = int(input("Digite seu saldo atual: "))
add = int(input("Quantos créditos você quer adicionar: "))
atual = saldo + add
print(f"Agora você tem {atual} créditos")

#14. Cadastro múltiplos usuários
usu1 = int(input("Insira usuário 1: "))
usu2 = int(input("Insira usuário 2: "))
usu3 = int(input("Insira usuário 3: "))
usu4 = int(input("Insira usuário 4: "))
usu5 = int(input("Insira usuário 5: "))
print("Esses são os usuários cadastrados: ",usu1,",",usu2,",",usu3,",",usu4,",",usu5)

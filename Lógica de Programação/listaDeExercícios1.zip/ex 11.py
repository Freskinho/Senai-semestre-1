#11. Sistema de média escolar
n1 = int(input("Insira sua nota 1: "))
n2 = int(input("Insira sua nota 2: "))
n3 = int(input("Insira sua nota 3: "))
media = (n1+n2+n3)/3
if media >= 7:
    print("Aprovado")
elif media >=5:
    print("Recuperação")
else:
    print("Reprovado")

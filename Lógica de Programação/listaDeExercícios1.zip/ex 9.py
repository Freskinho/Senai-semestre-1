#9. Lista de desenvolvedores
devs = ["Marcos", "Lucas", "Rodrigo", "Gabriel", "Dezzotti"]
for devs in devs:
    print(devs)

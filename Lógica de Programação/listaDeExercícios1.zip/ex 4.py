#4. Verificador de acesso
idd = input("Digite sua idade: ")
if idd >=18:
    print("Acesso permitido")
else:
    print("Acesso negado")

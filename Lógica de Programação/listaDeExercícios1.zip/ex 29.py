#29. Dashboard simples
vendas = [
    [120, 300, 250]
    [400, 150, 600]
]

total_geral = 0
maior_vendas = 0

for linha in vendas:
    total_linha = sum(linha)

    print("Total da linha: ", total_linha)

    total_geral += total_linha

    if max(linha) > maior_vendas:
        maior_vendas = max(linha)

print("\nTotal geral: ", total_geral)
print("Maior venda: ", maior_vendas)

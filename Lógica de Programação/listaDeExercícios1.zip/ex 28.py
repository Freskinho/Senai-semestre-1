#28. Mini sistema de boletim
alunos = []
for i in range(5):
    nome = input(f"Digite o nome do aluno {i + i}: ")
    nota = float(input("Digite a nota: "))
    alunos.append([nome, nota])
print("\nAlunos aprovados")
for aluno in alunos:
    nome = aluno[0]
    nota = aluno[1]
    if nota>= 7:
        print(nome, "-", nota)

#19. Verificador de números pares
pares = 0
for i in range(10):
    numero = int(input(f"Digite o {i + 1} número: "))
    if numero % 2 == 0:
        pares += 1
print("Total de números pares: ", pares)

#1. Cadastro de usuário
nome = input("Digite seu nome: ")
idade = input("Digite sua idade: ")
email = input("Digite seu email: ")
print("Olá, ",nome,"! Você tem ",idade," anos e seu email é ",email)

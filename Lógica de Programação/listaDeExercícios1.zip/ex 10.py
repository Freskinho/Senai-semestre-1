#10. Busca em lista
usuarios = ["Ricardo", "Rodrigo", "Ronaldo", "Rafael", "Rivaldo"]
nome = input("Digite um nome para procura-lo: ")
if nome in usuarios:
    print("Usuário encontrado!")
else:
    print("Usuário não encontrado")

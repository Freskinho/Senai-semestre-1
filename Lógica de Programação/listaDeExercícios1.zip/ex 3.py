#3. Conversor de armazenamento
tamanho = int(input("Qual é o tamanho do seu arquivo em MB: "))
kb = tamanho * 1024
print(f"Seu arquivo tem {kb} KB")

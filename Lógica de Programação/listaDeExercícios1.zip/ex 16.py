#16. Caixa de suoermercado
p1 = int(input("Insira o preço do produto 1: "))
p2 = int(input("Insira o preço do produto 2: "))
p3 = int(input("Insira o preço do produto 3: "))
p4 = int(input("Insira o preço do produto 4: "))
p5 = int(input("Insira o preço do produto 5: "))
conta = (p1+p2+p3+p4+p5)*0.1+p1+p2+p3+p4+p5
print ("A conta total ficou em: ",conta)

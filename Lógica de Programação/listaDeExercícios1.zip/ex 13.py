#13. Validador de senha
password = ["12345678"]
senha = " "
while senha != password:
    senha = input("Digite sua senha: ")
    if senha in password:
        print("Senha válida")
        break
    else:
        print("Senha inválida")
